// Function Definition : Collection of stmts rouped together to perform a operation
  /* return type is optional as we can remove it but that if we use void as return type in dart but void in dart means we are not returning
    anything  from uor method body but void is also optional. 
example: int findarea(int length, int breadth){
            function body
            return length*breadth;  }
            
            void findarea(int length, int breadth)
            {
                function body
                return length*breadth;
                }
        // properties of function in dart
        -> Function in Dart are objects.
        -> Function can be assigned to be variable or passed as parameter to other function.
        -> All function in dart return value 
        -> If no return value is specified the function return NULL
        -> Specifying return type is optional but is recommended as per code convention */